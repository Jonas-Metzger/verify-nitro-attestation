#ifndef _SYS_REG_H
#define _SYS_REG_H

#include <limits.h>
#include <unistd.h>

#include <bits/reg.h>

#endif

#ifndef __wasm_basics___typedef_uid_t_h
#define __wasm_basics___typedef_uid_t_h

typedef unsigned uid_t;

#endif

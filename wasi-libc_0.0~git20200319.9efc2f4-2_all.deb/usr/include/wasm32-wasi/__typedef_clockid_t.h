#ifndef __wasilibc___typedef_clockid_t_h
#define __wasilibc___typedef_clockid_t_h

typedef const struct __clockid *clockid_t;

#endif

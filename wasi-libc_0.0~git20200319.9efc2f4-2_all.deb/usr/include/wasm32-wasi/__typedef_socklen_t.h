#ifndef __wasilibc___typedef_socklen_t_h
#define __wasilibc___typedef_socklen_t_h

typedef unsigned socklen_t;

#endif

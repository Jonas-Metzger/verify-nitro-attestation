#ifndef __wasilibc___macro_FD_SETSIZE_h
#define __wasilibc___macro_FD_SETSIZE_h

#define FD_SETSIZE 1024

#endif
